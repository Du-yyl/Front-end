/*!*
  * Time:${DATE} ${TIME} ${SECOND}
  * Name:${FILE_NAME}
  * Path:${DIR_PATH}
  * ProjectName:${PROJECT_NAME}
  * Author:${USER}
  *
  *  Il n'ya qu'un héroïsme au monde : c'est de voir le monde tel qu'il est et de l'aimer.
  */

